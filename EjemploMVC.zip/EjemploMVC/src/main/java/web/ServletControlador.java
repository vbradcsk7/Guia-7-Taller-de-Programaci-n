package web;

import datos.PersonaDaoJDBC;
import domain.Persona;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ServletControlador")
public class ServletControlador extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accion = request.getParameter("accion");
        if (accion != null) {
            switch (accion) {
                case "editar":
                    this.editarPersona(request, response);
                    break;
                case "eliminar":
                    this.eliminarPersona(request, response);
                    break;
                default:
                    this.accionDefault(request, response);
            }
        } else {
            this.accionDefault(request, response);
        }
    }

    private void accionDefault(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Persona> personas = new PersonaDaoJDBC().listar();
        System.out.println("personas = " + personas);
        HttpSession sesion = request.getSession();
        sesion.setAttribute("personas", personas);
        sesion.setAttribute("totalPersonas", personas.size());
//        request.getRequestDispatcher("personas.jsp").forward(request, response);
        response.sendRedirect("personas.jsp");

    }

    private void editarPersona(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //recuperamos el idPersona
        int idPersona = Integer.parseInt(request.getParameter("idPersona"));
        Persona persona = new PersonaDaoJDBC().encontrar(new Persona(idPersona));
        request.setAttribute("persona", persona);
        String jspEditar = "/WEB-INF/pagina/persona/editarPersona.jsp";
        request.getRequestDispatcher(jspEditar).forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accion = request.getParameter("accion");
        if (accion != null) {
            switch (accion) {
                case "insertar":
                    this.insertarPersona(request, response);
                    break;
                case "modificar":
                    this.modificarPersona(request, response);
                    break;
                default:
                    this.accionDefault(request, response);
            }
        } else {
            this.accionDefault(request, response);
        }

    }

    private void insertarPersona(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //recuperar los valores del formulario agregar persona
        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String email = request.getParameter("email");
        String telefono = request.getParameter("telefono");

        //crear el objeto de persona
        Persona persona = new Persona(nombre, apellido, email, telefono);

        //insertar el nuevo objeto en la BD
        int registrosModificados = new PersonaDaoJDBC().insertar(persona);
        System.out.println("registrosModificados = " + registrosModificados);

        //redirigimos hacia accion por default
        this.accionDefault(request, response);
    }

    private void modificarPersona(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //recuperamos los valores del formulario editarPersona
        int idPersona = Integer.parseInt(request.getParameter("idPersona"));
        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String email = request.getParameter("email");
        String telefono = request.getParameter("telefono");

        //Creamos el objeto de persona (modelo)
        Persona persona = new Persona(idPersona, nombre, apellido, email, telefono);

        //Modificar el  objeto en la base de datos
        int registrosModificados = new PersonaDaoJDBC().actualizar(persona);
        System.out.println("registrosModificados = " + registrosModificados);

        //Redirigimos hacia accion por default
        this.accionDefault(request, response);
    }

    private void eliminarPersona(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //recuperamos los valores del formulario editarPersona
        int idPersona = Integer.parseInt(request.getParameter("idPersona"));

        //Creamos el objeto de persona (modelo)
        Persona persona = new Persona(idPersona);

        //eliminar el  objeto en la base de datos
        int registrosModificados = new PersonaDaoJDBC().eliminar(persona);
        System.out.println("registrosModificados = " + registrosModificados);

        //Redirigimos hacia accion por default
        this.accionDefault(request, response);

    }
}
